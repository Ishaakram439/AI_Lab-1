Captured console output from running lab1_rules.py and lab1_compare.py. Re-run the scripts to reproduce these files.
