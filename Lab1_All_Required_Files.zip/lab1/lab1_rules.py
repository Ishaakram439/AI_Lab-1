"""Transparent scholarship-screening rules for AI Lab 1.

All values are synthetic teaching examples, not real scholarship decisions.
Run from the repository root:
    python lab1/lab1_rules.py
"""
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUT_FILE = ROOT / "inputs" / "test_cases.csv"


def symbolic(score, documents_complete, identity_verified, eligibility_met):
    """Return Review only when every explicit requirement is satisfied."""
    return (
        "Review"
        if documents_complete
        and score >= 70
        and identity_verified
        and eligibility_met
        else "Hold"
    )


def main():
    print("LAB 1 - SYMBOLIC RULE TESTS")
    print("Synthetic demonstration data only; Review means human review, not approval.")
    print("-" * 112)
    with INPUT_FILE.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    all_passed = True
    for row in rows:
        score = int(row["score"])
        documents_complete = row["documents_complete"].lower() == "true"
        identity_verified = row["identity_verified"].lower() == "true"
        eligibility_met = row["eligibility_met"].lower() == "true"
        expected = row["expected_symbolic"]
        actual = symbolic(score, documents_complete, identity_verified, eligibility_met)
        passed = actual == expected
        all_passed = all_passed and passed

        print(f"Case: {row['case_id']} - {row['case_name']}")
        print(
            "Input: "
            f"score={score}, documents_complete={documents_complete}, "
            f"identity_verified={identity_verified}, eligibility_met={eligibility_met}"
        )
        print(f"Expected result: {expected}")
        print(f"Actual result:   {actual}")
        print(f"Test status:     {'PASS' if passed else 'FAIL'}")
        print(f"Reason:          {row['reason']}")
        print("-" * 112)

    # Separate guided boundary/edge checks requested in the manual.
    print("ADDITIONAL EDGE CHECKS (separate from the four core cases)")
    checks = [
        ("score boundary below threshold", symbolic(69, True, True, True), "Hold"),
        ("missing documents", symbolic(82, False, True, True), "Hold"),
    ]
    for label, actual, expected in checks:
        print(f"{label}: expected={expected}, actual={actual}, status={'PASS' if actual == expected else 'FAIL'}")
    print(f"OVERALL CORE TESTS: {'PASS' if all_passed else 'FAIL'}")


if __name__ == "__main__":
    main()
