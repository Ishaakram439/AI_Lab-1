test_cases.csv contains four synthetic core cases. Boolean values are True/False. All numeric values are invented for classroom demonstration only.
