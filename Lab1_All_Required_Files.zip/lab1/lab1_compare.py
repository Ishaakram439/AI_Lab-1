"""Compare transparent symbolic rules with a probability threshold.

Run from the repository root:
    python lab1/lab1_compare.py

The probability values are invented demonstration inputs, not calibrated model
predictions and not evidence of real-world accuracy.
"""
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUT_FILE = ROOT / "inputs" / "test_cases.csv"


def symbolic(score, complete, identity_verified, eligibility_met):
    return (
        "Review"
        if complete and score >= 70 and identity_verified and eligibility_met
        else "Hold"
    )


def threshold(probability):
    return "Review" if probability >= 0.70 else "Hold"


def main():
    print("LAB 1 - SYMBOLIC VS PROBABILITY THRESHOLD")
    print("Probability threshold: 0.70 (synthetic demonstration values)")
    print("-" * 92)
    print(f"{'Case':<23} {'Symbolic':<12} {'Threshold':<12} {'Disagreement':<14} Reason")
    print("-" * 92)

    with INPUT_FILE.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    for row in rows:
        symbolic_result = symbolic(
            int(row["score"]),
            row["documents_complete"].lower() == "true",
            row["identity_verified"].lower() == "true",
            row["eligibility_met"].lower() == "true",
        )
        threshold_result = threshold(float(row["probability"]))
        disagreement = symbolic_result != threshold_result
        print(
            f"{row['case_name']:<23} {symbolic_result:<12} "
            f"{threshold_result:<12} {str(disagreement):<14} {row['reason']}"
        )

    print("-" * 92)
    print("Interpretation: disagreement shows different encoded criteria, not which method is more accurate.")
    print("No ground-truth scholarship outcomes are supplied, so accuracy cannot be calculated.")


if __name__ == "__main__":
    main()
